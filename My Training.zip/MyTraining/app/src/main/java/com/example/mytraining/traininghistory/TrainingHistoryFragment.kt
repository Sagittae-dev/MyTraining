package com.example.mytraining.traininghistory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mytraining.MainActivity.Companion.trainingsHistoryMap
import com.example.mytraining.R
import kotlinx.android.synthetic.main.fragment_training_history_list.*


/**
 * A fragment representing a list of Items.
 */
class TrainingHistoryFragment : Fragment() {

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        listOfHistoryTrainingListView?.layoutManager = LinearLayoutManager(context)
        listOfHistoryTrainingListView?.adapter = MyItemRecyclerViewAdapter(trainingsHistoryMap)
        listOfHistoryTrainingListView?.adapter?.notifyDataSetChanged()
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_training_history_list, container, false)
    }

}


