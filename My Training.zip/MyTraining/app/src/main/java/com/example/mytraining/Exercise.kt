package com.example.mytraining


import java.io.Serializable

data class Exercise (
    var exerciseName : String = "",
    var listOfSeriesInExrercise : ArrayList<Series> = arrayListOf(),
    var listOfSeriesInExrerciseLength : Int= 0,
    var exerciseAnnotations : String = "No annotations"
) : Serializable
