package com.example.mytraining

import java.io.Serializable

data class Series (
    var weight : Int = 0,
    var reps : Int = 0,
    var annotationsToSeries : String = "No Annotations"
) : Serializable
