package com.example.mytraining.traininghistory

import android.annotation.SuppressLint
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.mytraining.MainActivity.Companion.applicationContext
import com.example.mytraining.R
import com.example.mytraining.Training

import com.example.mytraining.dummy.DummyContent.DummyItem

/**
 * [RecyclerView.Adapter] that can display a [DummyItem].
 * TODO: Replace the implementation with code for your data type.
 */
class MyItemRecyclerViewAdapter(private val trainings: HashMap<String, Training>) : RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.training_item, parent, false)
        return ViewHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = trainings.toList()[position]
        holder.layout.tag = currentItem.first
        holder.item
        holder.timeDateTextView?.text = currentItem.second.dateAndTime
        holder.accountNameTextView?.text = currentItem.second.accountNameOrTrainedPerson
        /*val adapter = ArrayAdapter(applicationContext(), android.R.layout.simple_list_item_1, currentItem.second.exercisesOnTrainingList)
        holder.exercisesInOneTrainingListView.adapter = adapter
        adapter.notifyDataSetChanged()*/
        holder.firstExercise?.text = currentItem.second.exercisesOnTrainingList[0].exerciseName + " ..."
    }


    override fun getItemCount(): Int = trainings.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val item: Training? = null
        var layout = view.findViewById<ConstraintLayout>(R.id.gamesHistoryItemConstraintLayout)
        val timeDateTextView = view.findViewById<TextView>(R.id.timeDateTextView)
        val accountNameTextView = view.findViewById<TextView>(R.id.accountNameTextView)
        //var exercisesInOneTrainingListView: ListView = view.findViewById(R.id.exercisesInOneTrainingListView)
        val firstExercise = view.findViewById<TextView>(R.id.firstExerciseInTrainingTextView)
    }
}