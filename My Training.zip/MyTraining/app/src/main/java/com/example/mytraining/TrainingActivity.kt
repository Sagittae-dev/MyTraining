package com.example.mytraining

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.Chronometer
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.mytraining.MainActivity.Companion.applicationContext
import kotlinx.android.synthetic.main.activity_training.*
import java.time.LocalDate
import java.time.LocalTime

var chronometer : Chronometer = Chronometer(applicationContext())
var chronometerStopTime: Long = 0
class TrainingActivity : AppCompatActivity() {

    companion object{
        private const val CHANNEL_ID = "timer_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_training)
        chronometer = findViewById(R.id.chronometerText)
        showNotification()
    }


    fun startTrainingTimer(view: View){
        setTimeAndDate()
        startChronometer()
    }

    @SuppressLint("SetTextI18n")
    private fun setTimeAndDate() {

        editTextDate.setText(LocalDate.now().dayOfMonth.toString() +"."+ monthOrMinuteWithZero(LocalDate.now().monthValue) +"."+ LocalDate.now().year.toString(), TextView.BufferType.EDITABLE)
        editTextTime.setText(LocalTime.now().hour.toString() +":"+ monthOrMinuteWithZero(LocalTime.now().minute))
    }

    fun monthOrMinuteWithZero(monthOrMinute: Int): String {
        return if(monthOrMinute <10){
            "0$monthOrMinute"
        } else
            monthOrMinute.toString()
    }

    @SuppressLint("SetTextI18n")
    private fun startChronometer() {
        startTrainingTimerButton.visibility = View.GONE
        chronometer.setOnChronometerTickListener {
            val time : Long = (SystemClock.elapsedRealtime() - it.base) //+ chronometerStopTime
            val h = time/3600000
            val m = (time - h*3600000)/60000
            val s =(time - h*3600000- m*60000)/1000
            val hh = h.toString()
            val mm = monthOrMinuteWithZero(m.toInt())
            val ss = monthOrMinuteWithZero(s.toInt())
            it.text = "$hh:$mm:$ss"
            chronometerStopTime = time
        }
        chronometer.start()
    }

    fun resumeTrainingTimer(view: View){
        resumeTrainingTimerButton.visibility = View.GONE
        chronometer.base = SystemClock.elapsedRealtime() - chronometerStopTime
        startChronometer()
    }
    fun pauseChronometer(view: View){
        resumeTrainingTimerButton.visibility = View.VISIBLE
        chronometer.stop()
    }

    private fun showNotification() {
        //val nManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
       // nManager.createNotificationChannel(CHANNEL_ID, "MyTimer", true)
        val intent = Intent(this, TrainingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        /*
        private fun createNotificationChannel() {
            // Create the NotificationChannel, but only on API 26+ because
            // the NotificationChannel class is new and not in the support library
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val name = getString(R.string.channel_name)
                val descriptionText = getString(R.string.channel_description)
                val importance = NotificationManager.IMPORTANCE_DEFAULT
                val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                    description = descriptionText
                }
                // Register the channel with the system
                val notificationManager: NotificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannel(channel)
            }
        }*/


        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.plusincircle)
            .setContentTitle("My notification")
            .setContentText("Hello World!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            // Set the intent that will fire when the user taps the notification
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)



        with(NotificationManagerCompat.from(this)) {
            val notifyID = 10
            notify(notifyID, builder.build())
        }
    }

}