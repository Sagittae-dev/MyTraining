package com.example.mytraining

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentPagerAdapter
import com.example.mytraining.traininghistory.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_training_history_list.*

class MainActivity :  AppCompatActivity()  {
    init {
        instance = this
    }
companion object{
    private var instance: MainActivity? = null
    fun applicationContext() : Context { return instance!!.applicationContext }
    val trainingsHistoryMap: HashMap<String, Training> = hashMapOf()
}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        updateTrainingHistoryList()
        setViewPager()
        setFragment(1)
        val context: Context = MainActivity.applicationContext()
    }

// PAGERY, FARGMENTY
    private fun getFragmentPagerAdapter()=
        object : FragmentPagerAdapter(supportFragmentManager) {
            override fun getItem(position: Int): Fragment = when(position) {
                0-> TrainingHistoryFragment()
                1-> NewTrainingFragment()
                //2-> //PlayersFragment()
                else->{
                    Log.wtf("problem", "problem z pagerem")
                    Fragment()
                }
            }
            override fun getCount(): Int = 3
        }
    private fun setViewPager(){
        viewPager.adapter = getFragmentPagerAdapter()
    }
    private fun setFragment(fragment: Int) {
        viewPager.setCurrentItem(fragment,false)
    }
//PAGERY, FRAGMENTY

    private fun updateTrainingHistoryList() {

        //todo Pobrać listę z firebase

        val training1 = Training("13.05.2020", "Szymon", arrayListOf(
            Exercise("Martwy", arrayListOf(
                Series(100, 5,"ok"),
                Series(100,4,"ok"))),
            Exercise("Wiosłowanie", arrayListOf(
                Series(50,10,"ciezko"),
                Series(60,8,"ciezko"),
                Series(40,10,"lekko"))),
            Exercise("żurawie", arrayListOf(
                Series(0,4,"ciezko"),
                Series(0,3,"lekko"),
                Series(0,5,"ciezko")))
        ),"Trening na szybko")

        val training2 = Training("15.05.2020", "Mateusz", arrayListOf(
            Exercise("Przysiad", arrayListOf(
                Series(100, 3,"Lekko"),
                Series(100,2,"ok"))),
            Exercise("Klateczka", arrayListOf(
                Series(90,10,"lekko"),
                Series(80,8,"ciezko"),
                Series(70,10,"lekko"))),
            Exercise("Podciąganie", arrayListOf(
                Series(0,10,"ciezko"),
                Series(0,11,"lekko"),
                Series(0,9,"ciezko")))
        ),"Super trening")

        trainingsHistoryMap.put("pierwszy kod", training1)
        trainingsHistoryMap.put("drugi kod", training2)

        listOfHistoryTrainingListView?.adapter?.notifyDataSetChanged()
        //  todo KONIEC USTAWIANIE LISTY HISTORII TRENINGOW
    }

    fun goToChoosenTrainingActivity(view : View){
        val intent = Intent(applicationContext(), ChoosenHistoryTrainingActivity::class.java)
        val tag = view.tag?.toString()
        intent.putExtra("Training", trainingsHistoryMap[tag])
        Log.i("Informacja", tag!!)
        startActivity(intent)
    }

    fun startNewTraining(view: View){
        val intent= Intent(this, TrainingActivity::class.java)
        startActivity(intent)
    }
}